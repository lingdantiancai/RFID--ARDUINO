#include "include.h"
#include "ZIMO.h"

extern unsigned char data oprationcard;

uchar swapbit(uchar data udata)
{
  uchar data ii,tmp=0;
  for(ii=0;ii<8;ii++)
  {
    tmp<<=1;
    if(udata&0x01)
    {
      tmp|=0x01;
    }
    udata>>=1;
  }
  return tmp;
}

//״̬���
void CheckState(uchar data Screen)
{
  unsigned char data dat;
  CLR_LCD_DI;
  SET_LCD_RW;
  switch(Screen)
  {
    case SCREENLEFT:
      CLR_LCD_CS2; 
      break;
    case SCREENRIGHT:
      CLR_LCD_CS1;
    default:
      break;
  }   
  SET_LCD_EN;    
  SET_DATAPORT; 
  do
  { 
    dat=swapbit(STU_DATAPORT); 
    dat=0x90 & dat; //������4,7λΪ0ʱ�ſɲ���
  }while(!(dat==0x00));
  CLR_LCD_EN;
  SET_LCD_CS1;
  SET_LCD_CS2;
}

//����ʾ����
/*unsigned char ReadByte(uchar Screen)
{
  unsigned char dat;
  CheckState(Screen);
  SET_LCD_DI;
  SET_LCD_RW;
  switch(Screen)
  {
    case SCREENLEFT:
      CLR_LCD_CS2; 
      break;
    case SCREENRIGHT:
      CLR_LCD_CS1;
    default:
      break;
  }   
  SET_LCD_EN;
  SET_DATAPORT;
  dat=swapbit(STU_DATAPORT); 
  CLR_LCD_EN;
  SET_LCD_CS1;
  SET_LCD_CS2;
  return(dat);
} */
/*----------------------------------------------------------------------------------------------------*/
//д��ʾ����
//dat:��ʾ����
void WriteByte(unsigned char data dat,uchar data Screen)
{
  CheckState(Screen);
  SET_LCD_DI; 
  CLR_LCD_RW;
//  SEND_DATAPORT;
  LCD12864DataPort=swapbit(dat);
  switch(Screen)
  {
    case SCREENLEFT:
      CLR_LCD_CS2; 
      break;
    case SCREENRIGHT:
      CLR_LCD_CS1;
    default:
      break;
  }  
  SET_LCD_EN; 
  CLR_LCD_EN;
  SET_LCD_CS1;
  SET_LCD_CS2;  
}
/*-----------------------------------------------------------------------------------------------------*/
//��LCD��������
//command :����
void SendCommandToLCD(unsigned char data command,uchar data Screen)
{
  CheckState(Screen);
  CLR_LCD_DI;
  CLR_LCD_RW;
//  SEND_DATAPORT;
  LCD12864DataPort=swapbit(command);
  switch(Screen)
  {
    case SCREENLEFT:
      CLR_LCD_CS2; 
      break;
    case SCREENRIGHT:
      CLR_LCD_CS1;
    default:
      break;
  } 
  SET_LCD_EN; 
  CLR_LCD_EN;
  SET_LCD_CS1;
  SET_LCD_CS2;  
}
/*----------------------------------------------------------------------------------------------------*/
//�趨�е�ַ(ҳ)--X 0-7
void SetLine(unsigned char data line)
{
  line=line & 0x07; // 0<=line<=7
  line=line|0xb8; //1011 1xxx
  SendCommandToLCD(line,SCREENLEFT);
  SendCommandToLCD(line,SCREENRIGHT);
}
//�趨�е�ַ--Y 0-63
void SetColumn(unsigned char data column)
{
  uchar data column_tmp;
  column_tmp=column;
  column=column &0x3f; // 0=<column<=63
  column=column | 0x40; //01xx xxxx
  if(column_tmp>63)
  {
    SendCommandToLCD(column,SCREENRIGHT);
  }
  else
  {
    SendCommandToLCD(column,SCREENLEFT);
  }
}
//�趨��ʾ��ʼ��--XX
void SetStartLine(unsigned char data startline) //0--63
{
  startline=startline & 0x07;
  startline=startline|0xc0; //1100 0000
  SendCommandToLCD(startline,SCREENLEFT);
  SendCommandToLCD(startline,SCREENRIGHT);
}
//������ʾ
void SetOnOff(unsigned char data onoff)
{
  onoff=0x3e | onoff; //0011 111x
  SendCommandToLCD(onoff,SCREENLEFT);
  SendCommandToLCD(onoff,SCREENRIGHT);
}

/*---------------------------------------------------------------------------------------------------*/
//����
void ClearScreen(void)
{
  unsigned char i,j;
  for(i=0;i<8;i++)
  { 
    SetLine(i);
    for(j=0;j<64;j++)
    {
      WriteByte(0x00,SCREENLEFT);
      WriteByte(0x00,SCREENRIGHT);
    }
  }
}

void Clear88(uchar data lin,uchar data column,uchar data lin_x,uchar data column_y)
{
  uchar data i,j;
  uchar data Screen;
  uchar data lin_tmp=lin;
  uchar data column_tmp=column;
  if(((column<=7)&&((column+column_y)<=8))||(column>7))
  {
	  if((column<=7)&&((column+column_y)<=8))
	  {
	    Screen=SCREENLEFT;
	  }
	  else if(column>7)
	  {
	    Screen=SCREENRIGHT;
	  }
	  SetLine(lin);
	  SetColumn(column<<3);  
	  for(j=0;j<lin_x;j++)
	  {
	    for(i=0;i<(column_y<<3);i++) 
	    {
	      WriteByte(0x00,Screen);
	    }
	    lin++;
	    SetLine(lin);
	    SetColumn(column<<3);
	  }
  } 
  else if((column<=7)&&((column+column_y)>8))
  {
    Screen=SCREENLEFT;
    SetLine(lin);
    SetColumn(column<<3);  
    for(j=0;j<lin_x;j++)
    {
      for(i=0;i<((8-column)<<3);i++) 
      {
        WriteByte(0x00,Screen);
      }
      lin++;
      SetLine(lin);
      SetColumn(column<<3);
    }
    Screen=SCREENRIGHT;
    SetLine(lin_tmp);
    SetColumn(64);      
    for(j=0;j<lin_x;j++)
    {
      for(i=0;i<((column_tmp+column_y-8)<<3);i++) 
      {
        WriteByte(0x00,Screen);
      }
      lin_tmp++;
      SetLine(lin_tmp);
      SetColumn(64);
    }         
  }
}

/*--------------------------------------------------------------------------------------------------*/
//��ʾ8*16����
//��ת90��:��ģ�������з�
//lin:��(0-7), column: ��(0-15)
//address : ��ģ���׵�ַ
void Show816(unsigned char data lin,unsigned char data column,unsigned int data address)
{ 
  unsigned char data i,j;
  uchar data Screen;
  if(column>7)
  {
    Screen=SCREENRIGHT;
  }
  else
  {
    Screen=SCREENLEFT;
  }
  SetLine(lin);
  SetColumn(column<<3);
  for(j=0;j<2;j++)
  {
    for(i=0;i<8;i++) 
    {
      WriteByte( ASCII816[address][j*8+i],Screen);
    }
    lin++;
    SetLine(lin);
    SetColumn(column<<3);
  }
} 

/*void ShowReverse816(unsigned char lin,unsigned char column,uchar ucode)
{ 
  unsigned char i,j,k;
  uchar tmpread[8],tmpcolumn;
  uchar Screen;
  tmpcolumn=column;
  for(k=0;k<ucode;k++)
  {
    column=tmpcolumn;
    if(column>7)
    {
      Screen=SCREENRIGHT;
    }
    else
    {
      Screen=SCREENLEFT;
    }
    SetLine(lin);
    SetColumn(column<<3);
    for(j=0;j<2;j++)
    {
      ReadByte(Screen);//????
      for(i=0;i<8;i++) 
      {
        tmpread[i]=ReadByte(Screen);
      }
      SetColumn(column<<3);
      for(i=0;i<8;i++)
      {
        WriteByte( ~tmpread[i],Screen);
      }
      lin++;
      SetLine(lin);
      SetColumn(column<<3);
    }
    lin-=2;
    tmpcolumn++;
  }
} */

void ShowHZ1616(unsigned char data lin,unsigned char data column,unsigned int data address)
{ 
  unsigned char data i,j;
  uchar data Screen;
  if(column>7)
  {
    Screen=SCREENRIGHT;
  }
  else
  {
    Screen=SCREENLEFT;
  }  
  SetLine(lin);
  SetColumn(column<<3);
  for(j=0;j<2;j++)
  {
    for(i=0;i<16;i++) 
    {
      WriteByte( HZ1616[address][j*16+i] ,Screen);
    }
    lin++;
    SetLine(lin);
    SetColumn(column<<3);
  }
} 

void ShowHZ3232(unsigned char data lin,unsigned char data column,unsigned int data address)
{ 
  unsigned char data i,j;
  uchar data Screen;
  if(column>7)
  {
    Screen=SCREENRIGHT;
  }
  else
  {
    Screen=SCREENLEFT;
  }  
  SetLine(lin);
  SetColumn(column<<3);
  for(j=0;j<4;j++)
  {
    for(i=0;i<32;i++) 
    {
      WriteByte( HZ3232[address][j*32+i] ,Screen);
    }
    lin++;
    SetLine(lin);
    SetColumn(column<<3);
  }
} 

/*void ShowBCD2(unsigned char data lin,unsigned char data column,uchar data value)
{
  Show816(lin,column,(value>>4)&0x0f);
  Show816(lin,column+1,value&0x0f);
}*/

void ShowFloat816(unsigned char data lin,unsigned char data column,float data flt)
{
  signed long data flt100;
  uchar data ShowLCD[10];
  uchar data bNeg=0;
  uchar data i;
  flt*=100;
  if(flt<0)
  {
    bNeg=1;
    flt=-flt;
  }
  flt+=0.1;
  flt100=(signed long)flt;
  if(flt100>9999999)
  {
    flt100=9999999;
  }
  ShowLCD[7]=flt100/1000000;
  flt100%=1000000;
  ShowLCD[6]=flt100/100000;
  flt100%=100000;
  ShowLCD[5]=flt100/10000;
  flt100%=10000;
  ShowLCD[4]=flt100/1000;
  flt100%=1000; 
  ShowLCD[3]=flt100/100;
  flt100%=100;
  // ShowLCD[2]ΪС����
  ShowLCD[2]=16;
  ShowLCD[1]=flt100/10;
  flt100%=10; 
  ShowLCD[0]=flt100;
  
  flt100=(signed long)flt; 
  if(bNeg)
  {
    if((flt100<=9999999)&&(flt100>=1000000))
    {
      ShowLCD[8]=18;
      for(i=0;i<=8;i++)
      {
     	Show816(lin,column,ShowLCD[8-i]);
    	column++;
      }
    }
    else if((flt100<=999999)&&(flt100>=100000))
    {
      ShowLCD[7]=18;
      for(i=0;i<=7;i++)
      {
      	Show816(lin,column,ShowLCD[7-i]);
      	column++;
      }
    }
    else if((flt100<=99999)&&(flt100>=10000))
    {
      ShowLCD[6]=18;    	
      for(i=0;i<=6;i++)
      {
      	Show816(lin,column,ShowLCD[6-i]);
      	column++;
      }
    }
    else if((flt100<=9999)&&(flt100>=1000))
    {
      ShowLCD[5]=18;    	
      for(i=0;i<=5;i++)
      {
      	Show816(lin,column,ShowLCD[5-i]);
      	column++;
      }
    }
    else
    {
      ShowLCD[4]=18;    	
      for(i=0;i<=4;i++)
      {
      	Show816(lin,column,ShowLCD[4-i]);
      	column++;
      }
    }
  }
  else
  {
    if((flt100<=9999999)&&(flt100>=1000000))
    {
      for(i=0;i<=7;i++)
      {
     	Show816(lin,column,ShowLCD[7-i]);
    	column++;
      }
    }
    else if((flt100<=999999)&&(flt100>=100000))
    {
      for(i=0;i<=6;i++)
      {
      	Show816(lin,column,ShowLCD[6-i]);
      	column++;
      }
    }
    else if((flt100<=99999)&&(flt100>=10000))
    {
      for(i=0;i<=5;i++)
      {
      	Show816(lin,column,ShowLCD[5-i]);
      	column++;
      }
    }
    else if((flt100<=9999)&&(flt100>=1000))
    {
      for(i=0;i<=4;i++)
      {
      	Show816(lin,column,ShowLCD[4-i]);
      	column++;
      }
    }
    else
    {
      for(i=0;i<=3;i++)
      {
      	Show816(lin,column,ShowLCD[3-i]);
      	column++;
      }
    }  
  }       
}

/*----------------------------------------------------------------------------------------------------*/
void InitLcd0108(void) //��ʼ��LCD
{ 
  CLR_LCD_EN;
  SET_LCD_CS1;
  SET_LCD_CS2;
  SetStartLine(0); //��ʼ��:0*/
  SetOnOff(1);
  ClearScreen();
}

/*void ShowTime(void)
{
  ClearScreen();
  Show816(1,3,2); //2
  Show816(1,4,0); //0
  Show816(1,7,18); //-
  Show816(1,10,18);  
  Show816(3,3,17);  //:
  Show816(3,6,17); 
  ShowHZ1616(3,10,14); //����
  ShowHZ1616(3,12,15);
  ShowHZ1616(5,1,8); //�¶�
  ShowHZ1616(5,3,9);  
  Show816(5,5,17);  //:
}*/	

void ShowMenu(void)
{
  ClearScreen();
  ShowHZ1616(0,0,0); //��
  ShowHZ1616(0,2,1); //��
  Show816(0,4,17);//��
  if(oprationcard==REGCARD)
  {
    ShowHZ1616(2,0,10); //ע�� 
    ShowHZ1616(2,2,11); //    
  }
  else if(oprationcard==CONSUME)
  {
    ShowHZ1616(2,0,4); //��  
    ShowHZ1616(2,2,5); //��   
  }
  else if(oprationcard==ADDMONEY)
  {
    ShowHZ1616(2,0,6); //��ֵ 
    ShowHZ1616(2,2,7); //   
  }  
  Show816(2,4,17);//��
  ShowHZ1616(4,0,2); //��  
  ShowHZ1616(4,2,3); //��
  Show816(4,4,17);//��  
}

void ShowWelcome(void)
{
  ClearScreen();
  ShowHZ3232(2,0,0);
  ShowHZ3232(2,4,1);
  ShowHZ3232(2,8,2);
  ShowHZ3232(2,12,3);
}

/*void ShowBCD4(unsigned char lin,unsigned char column,uint udata)
{
  uchar BCD[4];
  uchar ii;
  
  BCD[0]=(uchar)((udata&0xf000)>>12);
  BCD[1]=(uchar)((udata&0x0f00)>>8);
  BCD[2]=(uchar)((udata&0x00f0)>>4);
  BCD[3]=(uchar)(udata&0x000f);
  for(ii=0;ii<4;ii++)
  {
    Show816(lin,column,BCD[ii]);
    column++;    
  }
} */