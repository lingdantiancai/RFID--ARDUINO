#include "STC11.h"

#define  LCD12864DataPort  P1
//#define  SEND_DATAPORT  DDRB=0xff
//#define  GET_DATAPORT  DDRB=0x00
#define  STU_DATAPORT  P1
#define  SET_DATAPORT  P1=0xff

sbit  lcd_di=P0^3;
sbit  lcd_rw=P0^2;
sbit  lcd_en=P0^4;
sbit  lcd_cs1=P4^2;
sbit  lcd_cs2=P0^0;

#define  SCREENLEFT  0
#define  SCREENRIGHT  1

#define  CLR_LCD_DI  lcd_di=0
#define  SET_LCD_DI  lcd_di=1

#define  SET_LCD_RW  lcd_rw=1
#define  CLR_LCD_RW  lcd_rw=0

#define  SET_LCD_EN  lcd_en=1
#define  CLR_LCD_EN  lcd_en=0

#define  SET_LCD_CS1  lcd_cs1=1
#define  CLR_LCD_CS1  lcd_cs1=0

#define  SET_LCD_CS2  lcd_cs2=1
#define  CLR_LCD_CS2  lcd_cs2=0
